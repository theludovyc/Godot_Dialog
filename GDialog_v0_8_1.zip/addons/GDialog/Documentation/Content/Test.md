# Testing

![icon](res://icon.png)
![DialogicTab](https://github.com/Jowan-Spooner/dialogic/blob/plugin-docs/addons/dialogic/Documentation/Content/Tutorials/Images/Dialogic_Tab.PNG)
![textevent](./Reference/Events/Images/Event_Text.PNG)


[GodotLink](res://addons/dialogic/Documentation/Content/Tutorials.md)
[GodotLinkHalf](Tutorials/Exporting)
[GithubLink](https://github.com/Jowan-Spooner/dialogic/blob/plugin-docs/addons/dialogic/Documentation/Content/Tutorials/BeginnersGuideStepByStep.md)
[RelativeLink](./Reference/Events/001.md)

[WorldWideWeb](https://google.com)