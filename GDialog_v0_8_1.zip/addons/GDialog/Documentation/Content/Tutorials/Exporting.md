# Exporting a game with dialogic

Before exporting, there is something important to do!

In the export window navigate to the resources tab. Add `\*.json, \*.cfg` to your resources to export.

![Image](https://github.com/Jowan-Spooner/dialogic/blob/plugin-docs/addons/dialogic/Documentation/Content/Tutorials/Images/ExportResources.PNG)
