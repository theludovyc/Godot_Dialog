# Events

Here you should find explanation for all the events and their settings and how to use them.

+ [Text Event](./Events/000)
+ [Character Join](./Events/001)
+ [Character Leave](./Events/002)

+ [Text event](./Events/000)
+ [Text event](./Events/000)
+ [Text event](./Events/000)
