# Portraits don't show up?

Make sure you use the [Character Join](Reference/Events/001.md) event! Otherwise they wont show up.

Sometimes you will have to play around with the offset and scale options in the character editor!