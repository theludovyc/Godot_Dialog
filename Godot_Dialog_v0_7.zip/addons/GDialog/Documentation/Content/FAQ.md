# FAQ Section

There are some things that many people don't instantly get to work.

Hopefully these pages can help.


[How do signals work?](./FAQ/Signals)
[Reasons why portraits might not show up](./FAQ/Portraits)
[Why can't I see the dialog?](./FAQ/ShowDialog)